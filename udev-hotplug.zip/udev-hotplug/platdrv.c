#nclude <linux/module.h>
#include <linux/platform_device.h>

static int sample_probe(struct platform_device *pdev)
{
	pr_info("%s: probe invoked\n", __func__);
	return 0;
}

static int sample_remove(struct platform_device *pdev)
{
	pr_info("%s: driver's exit invoked\n", __func__);
	return 0;
}

/* looking for a platform device with following Identification */
static struct platform_device_id veda_driver_ids[] = {
	{"sample", -1},
	{}
};

/* it creates the device(platform) type table for module */
MODULE_DEVICE_TABLE(platform, veda_driver_ids);

/* populate this with driver and device details */
static struct platform_driver veda_sample_driver = {
	.driver = {
		   .name = "veda-sample",
		   .owner = THIS_MODULE,
		   },
	.id_table = veda_driver_ids,
	.probe = sample_probe,
	.remove = sample_remove,
};

/* macro to register/unregister with platform core */
module_platform_driver(veda_sample_driver);

MODULE_AUTHOR("techveda.org");
MODULE_DESCRIPTION("platform driver example");
MODULE_LICENSE("GPL");
