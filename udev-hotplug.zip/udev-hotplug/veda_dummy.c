#include <linux/module.h>
#include <linux/mm.h>
#include<linux/platform_device.h>
#include<linux/ioport.h>
#include<linux/slab.h>
#include<linux/init.h>

struct platform_device *pdev;

static __init int dummy_init(void)
{
	int ret;
	pdev = platform_device_alloc("sample", -1);
	ret = platform_device_add(pdev);
	return 0;
}

static __exit void dummy_exit(void)
{

 	platform_device_del(pdev);
}

module_init(dummy_init);
module_exit(dummy_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("support@techveda.org");
